module.exports.GET = function(req, write, server, ctx) {
	write("OWOT subdomain test");
}